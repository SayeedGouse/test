import './App.css'
import Cart from './Cart'
function App() {
  return <Cart />
}

export default App
